from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, Response, session
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timedelta
from functools import wraps
from flask_migrate import Migrate
from sqlalchemy import extract
from werkzeug.utils import secure_filename
import os
from flask_wtf.csrf import CSRFProtect, generate_csrf

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-here'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///fusioncode.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# Initialize CSRF protection
csrf = CSRFProtect(app)

db = SQLAlchemy(app)
migrate = Migrate(app, db)
login_manager = LoginManager(app)
login_manager.login_view = 'login'

# Add CSRF token to all responses
@app.after_request
def add_csrf_token(response):
    response.headers['X-CSRFToken'] = generate_csrf()
    return response

# Database Models
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(128))
    full_name = db.Column(db.String(100))
    department = db.Column(db.String(50))
    role = db.Column(db.String(20), default='employee')  # admin, team_leader, employee, trainee, manager
    created_by = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    total_leave_days = db.Column(db.Integer, default=30)  # Annual leave balance
    profile_picture = db.Column(db.String(255), default='default.jpg')  # Path to profile picture
    tasks = db.relationship('Task', foreign_keys='Task.user_id', backref='assignee', lazy=True)
    assigned_tasks = db.relationship('Task', foreign_keys='Task.assigned_by', backref='creator', lazy=True)
    employees = db.relationship('User', backref=db.backref('admin', remote_side=[id]))
    login_logs = db.relationship('LoginLog', backref='user', lazy=True)
    attendance_records = db.relationship('Attendance', backref='user', lazy=True)

    def get_activity_stats(self):
        """Calculate user activity statistics"""
        logs = LoginLog.query.filter_by(user_id=self.id).all()
        
        if not logs:
            return {
                'total_logins': 0,
                'avg_session_duration': 0,
                'last_login': None,
                'most_active_hour': None
            }
        
        # Calculate total logins
        total_logins = len(logs)
        
        # Calculate average session duration
        completed_sessions = [log for log in logs if log.logout_time]
        if completed_sessions:
            total_duration = sum(
                (log.logout_time - log.login_time).total_seconds()
                for log in completed_sessions
            )
            avg_duration = total_duration / len(completed_sessions)
        else:
            avg_duration = 0
        
        # Get last login time
        last_login = max(logs, key=lambda x: x.login_time).login_time
        
        # Calculate most active hour
        hour_counts = {}
        for log in logs:
            hour = log.login_time.hour
            hour_counts[hour] = hour_counts.get(hour, 0) + 1
        
        most_active_hour = max(hour_counts.items(), key=lambda x: x[1])[0] if hour_counts else None
        
        return {
            'total_logins': total_logins,
            'avg_session_duration': avg_duration,
            'last_login': last_login,
            'most_active_hour': most_active_hour
        }

    def get_leave_balance(self):
        """Get the user's current leave balance and usage"""
        current_year = datetime.utcnow().year
        taken_leaves = Attendance.query.filter(
            Attendance.user_id == self.id,
            Attendance.status == 'leave',
            extract('year', Attendance.date) == current_year
        ).count()
        
        # Ensure total_leave_days is not None, default to 30 if it is
        total_days = self.total_leave_days if self.total_leave_days is not None else 30
        
        return {
            'total': total_days,
            'taken': taken_leaves,
            'remaining': total_days - taken_leaves
        }

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

class UserActivity(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    action = db.Column(db.String(100), nullable=False)
    details = db.Column(db.Text)
    ip_address = db.Column(db.String(50))
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    user = db.relationship('User', backref=db.backref('activities', lazy=True))

class LoginHistory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    login_time = db.Column(db.DateTime, default=datetime.utcnow)
    logout_time = db.Column(db.DateTime)
    ip_address = db.Column(db.String(50))
    user_agent = db.Column(db.String(200))
    user = db.relationship('User', backref=db.backref('login_history', lazy=True))

class TaskDependency(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    task_id = db.Column(db.Integer, db.ForeignKey('task.id'), nullable=False)
    depends_on_id = db.Column(db.Integer, db.ForeignKey('task.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationships
    task = db.relationship('Task', foreign_keys=[task_id], backref='dependencies')
    depends_on = db.relationship('Task', foreign_keys=[depends_on_id], backref='dependent_tasks')

class Task(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    status = db.Column(db.String(20), default='pending')
    priority = db.Column(db.String(20), default='medium')  # high, medium, low
    category = db.Column(db.String(50), default='general')  # development, design, testing, etc.
    due_date = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    comments = db.relationship('TaskComment', backref='task', lazy=True, cascade='all, delete-orphan')
    assigned_by = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    assigned_to_role = db.Column(db.String(20), nullable=False)

    def get_dependency_status(self):
        """Get the status of all dependencies for this task"""
        dependencies = TaskDependency.query.filter_by(task_id=self.id).all()
        status = {
            'total': len(dependencies),
            'completed': 0,
            'pending': 0,
            'overdue': 0
        }
        
        for dep in dependencies:
            if dep.depends_on.status == 'completed':
                status['completed'] += 1
            elif dep.depends_on.due_date and dep.depends_on.due_date < datetime.utcnow():
                status['overdue'] += 1
            else:
                status['pending'] += 1
                
        return status

    @staticmethod
    def get_task_analytics(user_id=None):
        """Get task analytics for all users or a specific user"""
        query = Task.query
        
        if user_id:
            query = query.filter_by(user_id=user_id)
        
        all_tasks = query.all()
        
        if not all_tasks:
            return {
                'total_tasks': 0,
                'completion_rate': 0,
                'priority_distribution': {'high': 0, 'medium': 0, 'low': 0},
                'category_distribution': {},
                'monthly_trends': {},
                'overdue_tasks': 0
            }
        
        # Calculate total tasks and completion rate
        total_tasks = len(all_tasks)
        completed_tasks = len([t for t in all_tasks if t.status == 'completed'])
        completion_rate = (completed_tasks / total_tasks * 100) if total_tasks > 0 else 0
        
        # Calculate priority distribution
        priority_distribution = {
            'high': len([t for t in all_tasks if t.priority == 'high']),
            'medium': len([t for t in all_tasks if t.priority == 'medium']),
            'low': len([t for t in all_tasks if t.priority == 'low'])
        }
        
        # Calculate category distribution
        category_distribution = {}
        for task in all_tasks:
            category_distribution[task.category] = category_distribution.get(task.category, 0) + 1
        
        # Calculate monthly trends
        monthly_trends = {}
        for task in all_tasks:
            month_key = task.created_at.strftime('%Y-%m')
            monthly_trends[month_key] = monthly_trends.get(month_key, 0) + 1
        
        # Calculate overdue tasks
        overdue_tasks = len([t for t in all_tasks if t.due_date and t.due_date < datetime.utcnow() and t.status != 'completed'])
        
        return {
            'total_tasks': total_tasks,
            'completion_rate': completion_rate,
            'priority_distribution': priority_distribution,
            'category_distribution': category_distribution,
            'monthly_trends': monthly_trends,
            'overdue_tasks': overdue_tasks
        }

class TaskComment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    task_id = db.Column(db.Integer, db.ForeignKey('task.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    user = db.relationship('User', backref='comments')

class LoginLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    login_time = db.Column(db.DateTime, nullable=False)
    logout_time = db.Column(db.DateTime)
    ip_address = db.Column(db.String(45))  # IPv6 addresses can be up to 45 characters

    def get_session_duration(self):
        if self.logout_time:
            return (self.logout_time - self.login_time).total_seconds() / 60  # Duration in minutes
        return None

class Attendance(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    date = db.Column(db.Date, nullable=False)
    status = db.Column(db.String(20), nullable=False)  # present, absent, leave
    reason = db.Column(db.String(200))  # For leave requests
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    __table_args__ = (
        db.UniqueConstraint('user_id', 'date', name='unique_attendance'),
    )

class Message(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    sender_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    receiver_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    content = db.Column(db.Text, nullable=False)
    is_read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    sender = db.relationship('User', foreign_keys=[sender_id], backref='sent_messages')
    receiver = db.relationship('User', foreign_keys=[receiver_id], backref='received_messages')

class LeaveRequest(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    start_date = db.Column(db.Date, nullable=False)
    end_date = db.Column(db.Date, nullable=False)
    reason = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(20), default='pending')  # pending, approved, rejected
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    approved_by = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    approved_at = db.Column(db.DateTime, nullable=True)

    # Explicitly specify foreign keys for relationships
    user = db.relationship('User', foreign_keys=[user_id], backref=db.backref('leave_requests', lazy=True))
    approver = db.relationship('User', foreign_keys=[approved_by], backref=db.backref('approved_leave_requests', lazy=True))

class BankDetail(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    bank_name = db.Column(db.String(100), nullable=False)
    account_number = db.Column(db.String(20), nullable=False)
    account_holder_name = db.Column(db.String(100), nullable=False)
    ifsc_code = db.Column(db.String(20), nullable=False)
    branch_name = db.Column(db.String(100), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Explicitly specify backref name to avoid conflicts
    user = db.relationship('User', backref=db.backref('bank_account_details', lazy=True))

class ContactForm(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), nullable=False)
    phone = db.Column(db.String(20), nullable=False)
    company = db.Column(db.String(100))
    project_type = db.Column(db.String(50), nullable=False)
    project_description = db.Column(db.Text, nullable=False)
    budget_range = db.Column(db.String(50), nullable=False)
    timeline = db.Column(db.String(50), nullable=False)
    additional_info = db.Column(db.Text)
    status = db.Column(db.String(20), default='New')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<ContactForm {self.full_name}>'

class OnboardingTask(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    status = db.Column(db.String(20), default='pending')  # pending, in_progress, completed
    due_date = db.Column(db.Date, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    completed_at = db.Column(db.DateTime)
    
    # Foreign Keys
    new_hire_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    assigned_to = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    created_by = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    
    # Relationships
    new_hire = db.relationship('User', foreign_keys=[new_hire_id], backref='onboarding_tasks')
    assignee = db.relationship('User', foreign_keys=[assigned_to], backref='assigned_onboarding_tasks')
    creator = db.relationship('User', foreign_keys=[created_by], backref='created_onboarding_tasks')
    
    def __repr__(self):
        return f'<OnboardingTask {self.title} for {self.new_hire.username}>'

class CompanyEvent(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    event_type = db.Column(db.String(50), nullable=False)  # meeting, training, celebration, etc.
    start_date = db.Column(db.DateTime, nullable=False)
    end_date = db.Column(db.DateTime, nullable=False)
    location = db.Column(db.String(200))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Foreign Keys
    organizer_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    
    # Relationships
    organizer = db.relationship('User', backref='organized_events')
    
    def __repr__(self):
        return f'<CompanyEvent {self.title} on {self.start_date}>'

class EmployeeSpotlight(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    content = db.Column(db.Text, nullable=False)
    image_url = db.Column(db.String(500))
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Foreign Keys
    employee_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    
    # Relationships
    employee = db.relationship('User', backref='spotlights')
    
    def __repr__(self):
        return f'<EmployeeSpotlight {self.title} for {self.employee.username}>'

class Meeting(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    start_time = db.Column(db.DateTime, nullable=False)
    end_time = db.Column(db.DateTime, nullable=False)
    location = db.Column(db.String(200))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(20), default='scheduled')  # Add status field
    
    # Foreign Keys
    organizer_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    
    # Relationships
    organizer = db.relationship('User', backref='organized_meetings')
    attendees = db.relationship('MeetingAttendee', backref='meeting', cascade='all, delete-orphan')
    agenda_items = db.relationship('MeetingAgenda', backref='meeting', cascade='all, delete-orphan')
    minutes = db.relationship('MeetingMinute', backref='meeting', cascade='all, delete-orphan')
    action_items = db.relationship('ActionItem', backref='meeting', cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<Meeting {self.title} on {self.start_time}>'

class MeetingAttendee(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    meeting_id = db.Column(db.Integer, db.ForeignKey('meeting.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    status = db.Column(db.String(20), default='pending')  # pending, accepted, declined
    
    # Relationships
    user = db.relationship('User', backref='meeting_attendances')
    
    def __repr__(self):
        return f'<MeetingAttendee {self.user.username} for meeting {self.meeting_id}>'

class MeetingAgenda(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    meeting_id = db.Column(db.Integer, db.ForeignKey('meeting.id'), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    order = db.Column(db.Integer, nullable=False)
    
    def __repr__(self):
        return f'<MeetingAgenda {self.title} for meeting {self.meeting_id}>'

class MeetingMinute(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    meeting_id = db.Column(db.Integer, db.ForeignKey('meeting.id'), nullable=False)
    content = db.Column(db.Text, nullable=False)
    created_by = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    creator = db.relationship('User', backref='created_minutes')
    
    def __repr__(self):
        return f'<MeetingMinute for meeting {self.meeting_id}>'

class ActionItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    meeting_id = db.Column(db.Integer, db.ForeignKey('meeting.id'), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    assigned_to = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    due_date = db.Column(db.Date, nullable=False)
    status = db.Column(db.String(20), default='pending')  # pending, in_progress, completed
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    assignee = db.relationship('User', backref='action_items')
    
    def __repr__(self):
        return f'<ActionItem {self.title} for meeting {self.meeting_id}>'

class LoginLogout(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    event_type = db.Column(db.String(10), nullable=False)  # 'login' or 'logout'
    timestamp = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    ip_address = db.Column(db.String(45))  # IPv6 compatible
    user_agent = db.Column(db.String(255))

    user = db.relationship('User', backref=db.backref('login_logout_events', lazy=True))

    def __repr__(self):
        return f'<LoginLogout {self.event_type} by {self.user.username} at {self.timestamp}>'

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

def is_admin():
    return current_user.is_authenticated and current_user.role == 'admin'

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or current_user.role != 'admin':
            flash('Access denied. Admin privileges required.', 'danger')
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated_function

def admin_or_manager_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or current_user.role not in ['admin', 'manager']:
            flash('You do not have permission to access this page.', 'danger')
            return redirect(url_for('dashboard'))
        return f(*args, **kwargs)
    return decorated_function

def role_required(roles):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not current_user.is_authenticated:
                flash('Please log in to access this page.', 'danger')
                return redirect(url_for('login'))
            if current_user.role not in roles:
                flash('You do not have permission to access this page.', 'danger')
                return redirect(url_for('dashboard'))
            return f(*args, **kwargs)
        return decorated_function
    return decorator

# Initialize database
def init_db():
    with app.app_context():
        db.create_all()
        # Create admin user if not exists
        if not User.query.filter_by(username='admin').first():
            admin = User(
                username='admin',
                email='admin@example.com',
                role='admin'
            )
            admin.password_hash = generate_password_hash('admin123')
            db.session.add(admin)
            db.session.commit()

# Routes
@app.route('/')
def index():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        remember = request.form.get('remember', False)
        
        user = User.query.filter_by(username=username).first()
        
        if user and check_password_hash(user.password_hash, password):
            login_user(user, remember=remember)
            
            # Record login history
            login_record = LoginHistory(
                user_id=user.id,
                ip_address=request.remote_addr,
                user_agent=request.user_agent.string
            )
            db.session.add(login_record)
            db.session.commit()
            
            flash('Login successful!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid username or password', 'danger')
    
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        
        if User.query.filter_by(username=username).first():
            flash('Username already exists')
            return redirect(url_for('register'))
        
        if User.query.filter_by(email=email).first():
            flash('Email already exists')
            return redirect(url_for('register'))
        
        user = User(username=username, email=email, role='admin')
        user.password_hash = generate_password_hash(password)
        db.session.add(user)
        db.session.commit()
        
        flash('Registration successful! Please login.', 'success')
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/dashboard')
@login_required
def dashboard():
    if current_user.role == 'admin':
        employees = User.query.filter_by(created_by=current_user.id).all()
        tasks = Task.query.filter(Task.user_id.in_([e.id for e in employees])).all()
    else:
        tasks = Task.query.filter_by(user_id=current_user.id).all()
        employees = None
    return render_template('dashboard.html', tasks=tasks, employees=employees, is_admin=current_user.role == 'admin')

@app.route('/tasks', methods=['GET', 'POST'])
@login_required
def tasks():
    if request.method == 'POST':
        if current_user.role not in ['admin', 'manager', 'team_leader']:
            return jsonify({'success': False, 'message': 'Unauthorized'}), 403
        
        try:
            title = request.form.get('title')
            description = request.form.get('description')
            assigned_to = request.form.get('assigned_to')
            due_date = datetime.strptime(request.form.get('due_date'), '%Y-%m-%d')
            priority = request.form.get('priority')
            
            if not all([title, assigned_to, due_date, priority]):
                return jsonify({'success': False, 'message': 'All fields are required'}), 400
            
            # Get the user being assigned to
            assignee = User.query.get(assigned_to)
            if not assignee:
                return jsonify({'success': False, 'message': 'Invalid user selected'}), 400
            
            # Check assignment permissions based on role
            if current_user.role == 'admin':
                # Admin can assign to managers only
                if assignee.role != 'manager':
                    return jsonify({'success': False, 'message': 'Admin can only assign tasks to managers'}), 403
            elif current_user.role == 'manager':
                # Manager can assign to team leaders, employees, and trainees
                if assignee.role not in ['team_leader', 'employee', 'trainee']:
                    return jsonify({'success': False, 'message': 'Manager can only assign tasks to team leaders, employees, and trainees'}), 403
            elif current_user.role == 'team_leader':
                # Team leader can assign to employees and trainees
                if assignee.role not in ['employee', 'trainee']:
                    return jsonify({'success': False, 'message': 'Team leader can only assign tasks to employees and trainees'}), 403
            
            task = Task(
                title=title,
                description=description,
                user_id=assigned_to,
                assigned_by=current_user.id,
                assigned_to_role=assignee.role,
                due_date=due_date,
                priority=priority,
                status='pending'
            )
            
            db.session.add(task)
            db.session.commit()
            
            return jsonify({'success': True, 'message': 'Task created successfully'})
        except Exception as e:
            db.session.rollback()
            return jsonify({'success': False, 'message': str(e)}), 500
    
    # For GET request
    if current_user.role == 'admin':
        # Admin can see all tasks
        tasks = Task.query.order_by(Task.created_at.desc()).all()
        # Admin can assign to managers only
        assignees = User.query.filter_by(role='manager').all()
    elif current_user.role == 'manager':
        # Manager can see tasks assigned to them and tasks they assigned
        tasks = Task.query.filter(
            (Task.user_id == current_user.id) | 
            (Task.assigned_by == current_user.id)
        ).order_by(Task.created_at.desc()).all()
        # Manager can assign to team leaders, employees, and trainees
        assignees = User.query.filter(User.role.in_(['team_leader', 'employee', 'trainee'])).all()
    elif current_user.role == 'team_leader':
        # Team leader can see tasks assigned to them and tasks they assigned
        tasks = Task.query.filter(
            (Task.user_id == current_user.id) | 
            (Task.assigned_by == current_user.id)
        ).order_by(Task.created_at.desc()).all()
        # Team leader can assign to employees and trainees
        assignees = User.query.filter(User.role.in_(['employee', 'trainee'])).all()
    else:
        # Regular users can only see tasks assigned to them
        tasks = Task.query.filter_by(user_id=current_user.id).order_by(Task.created_at.desc()).all()
        assignees = None
    
    return render_template('tasks.html', tasks=tasks, assignees=assignees, current_user_role=current_user.role)

@app.route('/tasks/<int:task_id>/edit', methods=['GET', 'POST'])
@login_required
def edit_task(task_id):
    task = Task.query.get_or_404(task_id)
    
    if current_user.role not in ['admin', 'manager', 'team_leader'] and current_user.id != task.user_id:
        flash('Unauthorized access', 'danger')
        return redirect(url_for('tasks'))
    
    if request.method == 'POST':
        try:
            task.title = request.form.get('title')
            task.description = request.form.get('description')
            task.due_date = datetime.strptime(request.form.get('due_date'), '%Y-%m-%d')
            task.priority = request.form.get('priority')
            
            if current_user.role in ['admin', 'manager', 'team_leader']:
                task.user_id = request.form.get('assigned_to')
            
            db.session.commit()
            flash('Task updated successfully', 'success')
            return redirect(url_for('tasks'))
        except Exception as e:
            db.session.rollback()
            flash(f'Error updating task: {str(e)}', 'danger')
            return redirect(url_for('edit_task', task_id=task_id))
    
    employees = User.query.filter(User.role.in_(['employee', 'trainee'])).all()
    return render_template('edit_task.html', task=task, employees=employees)

@app.route('/tasks/<int:task_id>/delete', methods=['POST'])
@login_required
def delete_task(task_id):
    task = Task.query.get_or_404(task_id)
    
    if current_user.role not in ['admin', 'manager']:
        return jsonify({'success': False, 'message': 'Unauthorized'}), 403
    
    try:
        db.session.delete(task)
        db.session.commit()
        return jsonify({'success': True, 'message': 'Task deleted successfully'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/tasks/<int:task_id>/update_status', methods=['POST'])
@login_required
def update_task_status(task_id):
    task = Task.query.get_or_404(task_id)
    
    if current_user.id != task.user_id and current_user.role not in ['admin', 'manager', 'team_leader']:
        return jsonify({'success': False, 'message': 'Unauthorized'}), 403
    
    try:
        status = request.json.get('status')
        if status not in ['pending', 'in_progress', 'completed']:
            return jsonify({'success': False, 'message': 'Invalid status'}), 400
        
        task.status = status
        db.session.commit()
        return jsonify({'success': True, 'message': 'Task status updated successfully'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/employees', methods=['GET'])
@login_required
@admin_or_manager_required
def employees():
    employees = User.query.filter(User.role != 'admin').all()
    return render_template('employees.html', 
                         employees=employees,
                         current_user_role=current_user.role)

@app.route('/employees/add', methods=['GET', 'POST'])
@login_required
@admin_or_manager_required
def add_worker():
    if request.method == 'GET':
        return render_template('add_employee.html')
        
    try:
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        role = request.form.get('role')
        full_name = request.form.get('full_name')
        department = request.form.get('department')

        # Validate required fields
        if not all([username, email, password, role, full_name, department]):
            flash('All fields are required', 'error')
            return redirect(url_for('add_worker'))

        # Validate role permissions
        if role == 'manager' and current_user.role != 'admin':
            flash('Only administrators can create manager accounts', 'error')
            return redirect(url_for('add_worker'))

        if role not in ['manager', 'team_leader', 'employee', 'trainee']:
            flash('Invalid role selected', 'error')
            return redirect(url_for('add_worker'))

        # Check if username or email already exists
        if User.query.filter_by(username=username).first():
            flash('Username already exists', 'error')
            return redirect(url_for('add_worker'))
        if User.query.filter_by(email=email).first():
            flash('Email already exists', 'error')
            return redirect(url_for('add_worker'))

        # Create new user
        new_user = User(
            username=username,
            email=email,
            full_name=full_name,
            department=department,
            role=role,
            created_by=current_user.id,
            profile_picture='default.jpg'
        )
        new_user.password_hash = generate_password_hash(password)

        db.session.add(new_user)
        db.session.commit()

        flash(f'Successfully added {full_name} as {role} in {department} department', 'success')
        return redirect(url_for('employees'))
    except Exception as e:
        db.session.rollback()
        flash(f'Error adding employee: {str(e)}', 'error')
        return redirect(url_for('add_worker'))

@app.route('/employees/<int:employee_id>/edit', methods=['GET', 'POST'])
@login_required
@admin_or_manager_required
def edit_employee(employee_id):
    employee = User.query.get_or_404(employee_id)
    
    # Check if current user has permission to edit this employee
    if current_user.role == 'manager' and employee.role in ['admin', 'manager']:
        flash('Managers can only edit team leaders, employees, and trainees', 'error')
        return redirect(url_for('employees'))
    
    if request.method == 'POST':
        try:
            # Update basic information
            employee.full_name = request.form.get('full_name')
            employee.email = request.form.get('email')
            employee.department = request.form.get('department')
            
            # Only admin can change role
            if current_user.role == 'admin':
                employee.role = request.form.get('role')
            
            # Handle profile picture upload
            if 'profile_picture' in request.files:
                file = request.files['profile_picture']
                if file and file.filename:
                    filename = secure_filename(file.filename)
                    os.makedirs(os.path.join(app.static_folder, 'uploads'), exist_ok=True)
                    filepath = os.path.join('uploads', f"{employee.username}_{filename}")
                    file.save(os.path.join(app.static_folder, filepath))
                    employee.profile_picture = filepath
            
            # Handle password change if provided
            new_password = request.form.get('password')
            if new_password:
                employee.password_hash = generate_password_hash(new_password)
            
            db.session.commit()
            flash('Employee information updated successfully', 'success')
            return redirect(url_for('employees'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error updating employee: {str(e)}', 'error')
            return redirect(url_for('edit_employee', employee_id=employee_id))
    
    return render_template('edit_employee.html', employee=employee)

@app.route('/employees/<int:employee_id>/delete', methods=['POST'])
@login_required
@admin_or_manager_required
@csrf.exempt
def delete_employee(employee_id):
    employee = User.query.get_or_404(employee_id)
    
    # Check if current user has permission to delete this employee
    if current_user.role == 'admin':
        # Admin can delete anyone except themselves
        if employee.id == current_user.id:
            return jsonify({'success': False, 'message': 'Cannot delete your own account'}), 403
    elif current_user.role == 'manager':
        # Manager can only delete team leaders, employees, and trainees
        if employee.role not in ['team_leader', 'employee', 'trainee']:
            return jsonify({'success': False, 'message': 'Unauthorized to delete this employee'}), 403
    else:
        return jsonify({'success': False, 'message': 'Unauthorized'}), 403
    
    try:
        # Delete all associated records
        Task.query.filter_by(user_id=employee.id).delete()
        Attendance.query.filter_by(user_id=employee.id).delete()
        LeaveRequest.query.filter_by(user_id=employee.id).delete()
        Message.query.filter((Message.sender_id == employee.id) | (Message.receiver_id == employee.id)).delete()
        
        # Delete the employee
        db.session.delete(employee)
        db.session.commit()
        
        return jsonify({'success': True, 'message': 'Employee deleted successfully'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/task/<int:task_id>/comment', methods=['POST'])
@login_required
def add_comment(task_id):
    task = Task.query.get_or_404(task_id)
    if task.user_id != current_user.id and current_user.role not in ['admin', 'manager', 'team_leader']:
        return jsonify({'success': False, 'message': 'Unauthorized'}), 403
    
    data = request.get_json()
    if not data or 'content' not in data:
        return jsonify({'success': False, 'message': 'Missing content'}), 400
    
    comment = TaskComment(
        content=data['content'],
        task_id=task_id,
        user_id=current_user.id
    )
    
    try:
        db.session.add(comment)
        db.session.commit()
        return jsonify({'success': True})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/logout')
@login_required
def logout():
    # Update the latest login record with logout time
    latest_login = LoginHistory.query\
        .filter_by(user_id=current_user.id, logout_time=None)\
        .order_by(LoginHistory.login_time.desc())\
        .first()
    
    if latest_login:
        latest_login.logout_time = datetime.utcnow()
        db.session.commit()
    
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('login'))

@app.route('/login_logout_history')
@login_required
def login_logout_history():
    # Get the appropriate users based on role
    if current_user.role == 'admin':
        # Admin can see everyone
        users = User.query.all()
    elif current_user.role == 'manager':
        # Manager can see team leaders, employees, and trainees
        users = User.query.filter(User.role.in_(['team_leader', 'employee', 'trainee'])).all()
    elif current_user.role == 'team_leader':
        # Team leader can see employees and trainees
        users = User.query.filter(User.role.in_(['employee', 'trainee'])).all()
    else:
        # Regular users can only see their own history
        users = [current_user]
    
    # Get events for the selected users
    events = LoginLogout.query.filter(LoginLogout.user_id.in_([user.id for user in users]))\
        .order_by(LoginLogout.timestamp.desc())\
        .all()
    
    return render_template('login_logout_history.html', events=events, users=users)

@app.route('/user/activity')
@login_required
def user_activity():
    # Get user's activities
    activities = UserActivity.query.filter_by(user_id=current_user.id)\
        .order_by(UserActivity.timestamp.desc())\
        .all()
    
    # Get user's login history
    login_history = LoginHistory.query.filter_by(user_id=current_user.id)\
        .order_by(LoginHistory.login_time.desc())\
        .all()
    
    return render_template('user_activity.html', 
                         activities=activities,
                         login_history=login_history)

@app.route('/admin/activity-logs')
@login_required
@role_required(['admin', 'manager'])
def activity_logs():
    # Get all activities
    activities = UserActivity.query\
        .join(User)\
        .order_by(UserActivity.timestamp.desc())\
        .all()
    
    # Get all login history
    login_history = LoginHistory.query\
        .join(User)\
        .order_by(LoginHistory.login_time.desc())\
        .all()
    
    return render_template('activity_logs.html',
                         activities=activities,
                         login_history=login_history)

@app.route('/task_analytics')
@login_required
def task_analytics():
    # Get analytics for all users if admin, otherwise for current user
    if current_user.role == 'admin':
        analytics = Task.get_task_analytics()
        user_analytics = {}
        for user in User.query.filter_by(role='employee').all():
            user_analytics[user.username] = Task.get_task_analytics(user.id)
    else:
        analytics = Task.get_task_analytics(current_user.id)
        user_analytics = None
    
    return render_template('task_analytics.html', 
                         analytics=analytics,
                         user_analytics=user_analytics,
                         is_admin=current_user.role == 'admin')

@app.route('/task/<int:task_id>/add_dependency', methods=['POST'])
@login_required
def add_task_dependency(task_id):
    task = Task.query.get_or_404(task_id)
    if not is_admin() and task.user_id != current_user.id:
        return jsonify({'success': False, 'message': 'Unauthorized'}), 403
    
    depends_on_id = request.form.get('depends_on_id')
    if not depends_on_id:
        return jsonify({'success': False, 'message': 'Dependency task ID is required'}), 400
    
    # Check if dependency already exists
    existing = TaskDependency.query.filter_by(
        task_id=task_id,
        depends_on_id=depends_on_id
    ).first()
    
    if existing:
        return jsonify({'success': False, 'message': 'Dependency already exists'}), 400
    
    # Check for circular dependencies
    if task_id == int(depends_on_id):
        return jsonify({'success': False, 'message': 'Cannot create circular dependency'}), 400
    
    dependency = TaskDependency(
        task_id=task_id,
        depends_on_id=depends_on_id
    )
    
    try:
        db.session.add(dependency)
        db.session.commit()
        return jsonify({'success': True})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/task/<int:task_id>/remove_dependency/<int:depends_on_id>', methods=['POST'])
@login_required
def remove_task_dependency(task_id, depends_on_id):
    task = Task.query.get_or_404(task_id)
    if not is_admin() and task.user_id != current_user.id:
        return jsonify({'success': False, 'message': 'Unauthorized'}), 403
    
    dependency = TaskDependency.query.filter_by(
        task_id=task_id,
        depends_on_id=depends_on_id
    ).first_or_404()
    
    try:
        db.session.delete(dependency)
        db.session.commit()
        return jsonify({'success': True})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/attendance')
@login_required
def attendance():
    year = request.args.get('year', datetime.now().year, type=int)
    month = request.args.get('month', datetime.now().month, type=int)
    employee_id = request.args.get('employee_id', type=int)
    
    # Get the first day of the month
    first_day = datetime(year, month, 1)
    # Get the last day of the month
    if month == 12:
        last_day = datetime(year + 1, 1, 1) - timedelta(days=1)
    else:
        last_day = datetime(year, month + 1, 1) - timedelta(days=1)
    
    # Get all dates in the month
    dates = []
    current_date = first_day
    while current_date <= last_day:
        dates.append(current_date)
        current_date += timedelta(days=1)
    
    # Get attendance records
    if current_user.role == 'admin':
        # Admin can view all employees' attendance
        users = User.query.filter_by(created_by=current_user.id).all()
        if employee_id:
            attendance_records = Attendance.query.filter(
                Attendance.user_id == employee_id,
                Attendance.date >= first_day.date(),
                Attendance.date <= last_day.date()
            ).all()
        else:
            attendance_records = Attendance.query.filter(
                Attendance.date >= first_day.date(),
                Attendance.date <= last_day.date()
            ).all()
    else:
        # Regular users can only view their own attendance
        users = None
        attendance_records = Attendance.query.filter(
            Attendance.user_id == current_user.id,
            Attendance.date >= first_day.date(),
            Attendance.date <= last_day.date()
        ).all()
    
    # Create a dictionary of attendance records for easy lookup
    attendance_dict = {record.date: record for record in attendance_records}
    
    return render_template('attendance.html',
                         dates=dates,
                         attendance_dict=attendance_dict,
                         current_month=month,
                         current_year=year,
                         users=users,
                         selected_employee=employee_id)

@app.route('/mark_attendance', methods=['POST'])
@login_required
def mark_attendance():
    if current_user.role not in ['admin', 'manager']:
        return jsonify({'success': False, 'message': 'Unauthorized'}), 403
    
    data = request.get_json()
    user_id = data.get('user_id')
    date = datetime.strptime(data.get('date'), '%Y-%m-%d').date()
    status = data.get('status')
    reason = data.get('reason', '')
    
    # Check if it's a weekend
    if date.weekday() >= 5:  # 5 is Saturday, 6 is Sunday
        return jsonify({'success': False, 'message': 'Cannot mark attendance for weekends'}), 400
    
    try:
        # Check if attendance record already exists
        existing_record = Attendance.query.filter_by(
            user_id=user_id,
            date=date
        ).first()
        
        if existing_record:
            existing_record.status = status
            existing_record.reason = reason
        else:
            attendance = Attendance(
                user_id=user_id,
                date=date,
                status=status,
                reason=reason
            )
            db.session.add(attendance)
        
        db.session.commit()
        return jsonify({'success': True})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/messages')
@login_required
def messages():
    # Get all messages for the current user
    received_messages = Message.query.filter_by(receiver_id=current_user.id).order_by(Message.created_at.desc()).all()
    sent_messages = Message.query.filter_by(sender_id=current_user.id).order_by(Message.created_at.desc()).all()
    
    # Mark unread messages as read
    unread_messages = Message.query.filter_by(receiver_id=current_user.id, is_read=False).all()
    for message in unread_messages:
        message.is_read = True
    db.session.commit()
    
    # Get list of users to send message to based on role
    if current_user.role in ['admin', 'team_leader', 'manager', 'trainee']:
        # These roles can message anyone
        users = User.query.filter(User.id != current_user.id).all()
    else:
        # Regular employees can only message admins, team leaders, and managers
        users = User.query.filter(
            User.role.in_(['admin', 'team_leader', 'manager']),
            User.id != current_user.id
        ).all()
    
    return render_template('messages.html', 
                         received_messages=received_messages,
                         sent_messages=sent_messages,
                         users=users)

@app.route('/send_message', methods=['GET', 'POST'])
@login_required
def send_message():
    if request.method == 'POST':
        try:
            receiver_id = request.form.get('receiver_id')
            content = request.form.get('content')
            
            if not receiver_id or not content:
                return jsonify({'success': False, 'message': 'Please fill in all fields'}), 400
            
            # Check if receiver exists
            receiver = User.query.get(receiver_id)
            if not receiver:
                return jsonify({'success': False, 'message': 'Invalid recipient'}), 400
            
            # Check if user has permission to message this recipient
            if current_user.role not in ['admin', 'team_leader', 'manager', 'trainee']:
                if receiver.role not in ['admin', 'team_leader', 'manager']:
                    return jsonify({'success': False, 'message': 'Unauthorized to message this user'}), 403
            
            message = Message(
                sender_id=current_user.id,
                receiver_id=receiver_id,
                content=content
            )
            db.session.add(message)
            db.session.commit()
            
            return jsonify({'success': True, 'message': 'Message sent successfully'})
        except Exception as e:
            db.session.rollback()
            return jsonify({'success': False, 'message': str(e)}), 500
    
    # For GET request, return the send message form
    if current_user.role in ['admin', 'team_leader', 'manager', 'trainee']:
        # These roles can message anyone
        users = User.query.filter(User.id != current_user.id).all()
    else:
        # Regular employees can only message admins, team leaders, and managers
        users = User.query.filter(
            User.role.in_(['admin', 'team_leader', 'manager']),
            User.id != current_user.id
        ).all()
    
    return render_template('send_message.html', users=users)

@app.route('/leave', methods=['GET', 'POST'])
@login_required
def leave():
    if request.method == 'POST':
        start_date = datetime.strptime(request.form.get('start_date'), '%Y-%m-%d').date()
        end_date = datetime.strptime(request.form.get('end_date'), '%Y-%m-%d').date()
        reason = request.form.get('reason')
        
        if start_date > end_date:
            flash('End date must be after start date')
            return redirect(url_for('leave'))
        
        leave_request = LeaveRequest(
            user_id=current_user.id,
            start_date=start_date,
            end_date=end_date,
            reason=reason
        )
        db.session.add(leave_request)
        db.session.commit()
        
        flash('Leave request submitted successfully!', 'success')
        return redirect(url_for('leave'))
    
    # Get leave requests based on user role
    if current_user.role == 'admin':
        # Admin can see all leave requests
        leave_requests = LeaveRequest.query.order_by(LeaveRequest.created_at.desc()).all()
    elif current_user.role == 'manager':
        # Manager can see team leader, trainee, and employee leave requests
        leave_requests = LeaveRequest.query.join(
            User, LeaveRequest.user_id == User.id
        ).filter(
            User.role.in_(['team_leader', 'trainee', 'employee'])
        ).order_by(LeaveRequest.created_at.desc()).all()
    elif current_user.role == 'team_leader':
        # Team leader can see trainee and employee leave requests
        leave_requests = LeaveRequest.query.join(
            User, LeaveRequest.user_id == User.id
        ).filter(
            User.role.in_(['trainee', 'employee'])
        ).order_by(LeaveRequest.created_at.desc()).all()
    else:
        # Regular users can only see their own leave requests
        leave_requests = LeaveRequest.query.filter_by(
            user_id=current_user.id
        ).order_by(LeaveRequest.created_at.desc()).all()
    
    return render_template('leave.html', leave_requests=leave_requests)

@app.route('/leave/<int:leave_id>/approve', methods=['POST'])
@login_required
def approve_leave(leave_id):
    leave_request = LeaveRequest.query.get_or_404(leave_id)
    requester = leave_request.user
    
    # Check if current user has permission to approve this leave request
    if current_user.role == 'admin':
        # Admin can approve any leave request
        pass
    elif current_user.role == 'manager':
        # Manager can approve team leader, trainee, and employee leave requests
        if requester.role not in ['team_leader', 'trainee', 'employee']:
            return jsonify({'success': False, 'message': 'Unauthorized to approve this leave request'}), 403
    elif current_user.role == 'team_leader':
        # Team leader can approve trainee and employee leave requests
        if requester.role not in ['trainee', 'employee']:
            return jsonify({'success': False, 'message': 'Unauthorized to approve this leave request'}), 403
    else:
        return jsonify({'success': False, 'message': 'Unauthorized'}), 403
    
    try:
        leave_request.status = 'approved'
        leave_request.approved_by = current_user.id
        leave_request.approved_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({'success': True})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/leave/<int:leave_id>/reject', methods=['POST'])
@login_required
def reject_leave(leave_id):
    leave_request = LeaveRequest.query.get_or_404(leave_id)
    requester = leave_request.user
    
    # Check if current user has permission to reject this leave request
    if current_user.role == 'admin':
        # Admin can reject any leave request
        pass
    elif current_user.role == 'manager':
        # Manager can reject team leader, trainee, and employee leave requests
        if requester.role not in ['team_leader', 'trainee', 'employee']:
            return jsonify({'success': False, 'message': 'Unauthorized to reject this leave request'}), 403
    elif current_user.role == 'team_leader':
        # Team leader can reject trainee and employee leave requests
        if requester.role not in ['trainee', 'employee']:
            return jsonify({'success': False, 'message': 'Unauthorized to reject this leave request'}), 403
    else:
        return jsonify({'success': False, 'message': 'Unauthorized'}), 403
    
    try:
        leave_request.status = 'rejected'
        leave_request.approved_by = current_user.id
        leave_request.approved_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({'success': True})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/bank_details', methods=['GET', 'POST'])
@login_required
def bank_details():
    if request.method == 'POST':
        if not is_admin() and current_user.bank_account_details:
            flash('You already have bank details saved', 'warning')
            return redirect(url_for('bank_details'))
        
        bank_name = request.form.get('bank_name')
        account_number = request.form.get('account_number')
        account_holder_name = request.form.get('account_holder_name')
        ifsc_code = request.form.get('ifsc_code')
        branch_name = request.form.get('branch_name')
        
        if not all([bank_name, account_number, account_holder_name, ifsc_code, branch_name]):
            flash('All fields are required', 'error')
            return redirect(url_for('bank_details'))
        
        bank_detail = BankDetail(
            user_id=current_user.id,
            bank_name=bank_name,
            account_number=account_number,
            account_holder_name=account_holder_name,
            ifsc_code=ifsc_code,
            branch_name=branch_name
        )
        
        try:
            db.session.add(bank_detail)
            db.session.commit()
            flash('Bank details saved successfully!', 'success')
            return redirect(url_for('bank_details'))
        except Exception as e:
            db.session.rollback()
            flash('Error saving bank details', 'error')
            return redirect(url_for('bank_details'))
    
    # For GET request
    if is_admin():
        # Admin can view all employees' bank details
        bank_details = BankDetail.query.join(User).filter(
            User.created_by == current_user.id
        ).all()
    else:
        # Regular users can only view their own bank details
        bank_details = BankDetail.query.filter_by(user_id=current_user.id).first()
    
    return render_template('bank_details.html', bank_details=bank_details, is_admin=is_admin())

@app.route('/download_bank_details')
@login_required
def download_bank_details():
    if not is_admin():
        flash('You do not have permission to access this page')
        return redirect(url_for('dashboard'))
    
    import csv
    from io import StringIO
    
    # Get all bank details for employees created by the admin
    bank_details = BankDetail.query.join(User).filter(
        User.created_by == current_user.id
    ).all()
    
    # Create CSV in memory
    output = StringIO()
    writer = csv.writer(output)
    
    # Write header
    writer.writerow(['Employee', 'Account Holder Name', 'Account Number', 'Bank Name', 'IFSC Code', 'Branch Name', 'Last Updated'])
    
    # Write data
    for detail in bank_details:
        writer.writerow([
            detail.user.username,
            detail.account_holder_name,
            detail.account_number,
            detail.bank_name,
            detail.ifsc_code,
            detail.branch_name,
            detail.updated_at.strftime('%Y-%m-%d %H:%M')
        ])
    
    # Prepare response
    output.seek(0)
    return Response(
        output,
        mimetype='text/csv',
        headers={
            'Content-Disposition': 'attachment; filename=bank_details.csv'
        }
    )

@app.route('/submit_contact', methods=['POST'])
def submit_contact():
    try:
        form_data = request.form
        new_contact = ContactForm(
            full_name=form_data['full_name'],
            email=form_data['email'],
            phone=form_data['phone'],
            company=form_data.get('company'),
            project_type=form_data['project_type'],
            project_description=form_data['project_description'],
            budget_range=form_data['budget_range'],
            timeline=form_data['timeline'],
            additional_info=form_data.get('additional_info')
        )
        db.session.add(new_contact)
        db.session.commit()
        
        # Send email notification to admin
        send_admin_notification(new_contact)
        
        return jsonify({
            'success': True,
            'message': 'Thank you for your inquiry. We will contact you soon!'
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': 'An error occurred. Please try again later.'
        }), 500

@app.route('/admin/contact_forms')
@login_required
@admin_required
def admin_contact_forms():
    contact_forms = ContactForm.query.order_by(ContactForm.created_at.desc()).all()
    return render_template('admin/contact_forms.html', contact_forms=contact_forms)

@app.route('/admin/contact_form/<int:form_id>')
@login_required
@admin_required
def get_contact_form(form_id):
    form = ContactForm.query.get_or_404(form_id)
    return jsonify({
        'success': True,
        'form': {
            'id': form.id,
            'full_name': form.full_name,
            'email': form.email,
            'phone': form.phone,
            'company': form.company,
            'project_type': form.project_type,
            'project_description': form.project_description,
            'budget_range': form.budget_range,
            'timeline': form.timeline,
            'additional_info': form.additional_info,
            'status': form.status,
            'created_at': form.created_at.strftime('%Y-%m-%d %H:%M:%S')
        }
    })

@app.route('/admin/contact_form/<int:form_id>/update_status', methods=['POST'])
@login_required
@admin_required
def update_contact_form_status(form_id):
    try:
        form = ContactForm.query.get_or_404(form_id)
        data = request.get_json()
        
        if 'status' not in data:
            return jsonify({
                'success': False,
                'message': 'Status is required'
            }), 400
            
        valid_statuses = ['New', 'Contacted', 'In Progress', 'Completed']
        if data['status'] not in valid_statuses:
            return jsonify({
                'success': False,
                'message': 'Invalid status'
            }), 400
            
        form.status = data['status']
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Status updated successfully'
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': 'An error occurred while updating status'
        }), 500

def send_admin_notification(contact_form):
    """Send email notification to admin when new contact form is submitted"""
    try:
        subject = f'New Contact Form Submission: {contact_form.full_name}'
        body = f'''
        New contact form submission received:
        
        Name: {contact_form.full_name}
        Email: {contact_form.email}
        Phone: {contact_form.phone}
        Company: {contact_form.company or 'N/A'}
        Project Type: {contact_form.project_type}
        Budget Range: {contact_form.budget_range}
        Timeline: {contact_form.timeline}
        
        Project Description:
        {contact_form.project_description}
        
        Additional Information:
        {contact_form.additional_info or 'None provided'}
        '''
        
        # You can implement your email sending logic here
        # For example, using Flask-Mail:
        # msg = Message(subject, recipients=[app.config['ADMIN_EMAIL']])
        # msg.body = body
        # mail.send(msg)
        
        pass  # Remove this line when implementing email sending
    except Exception as e:
        # Log the error but don't raise it to prevent affecting the form submission
        print(f"Error sending admin notification: {str(e)}")

# Onboarding Routes
@app.route('/onboarding', methods=['GET', 'POST'])
@login_required
def onboarding():
    if request.method == 'POST':
        if current_user.role not in ['admin', 'hr', 'manager']:
            flash('Unauthorized access', 'danger')
            return redirect(url_for('dashboard'))
        
        try:
            new_hire_id = request.form.get('new_hire_id')
            title = request.form.get('title')
            description = request.form.get('description')
            due_date = datetime.strptime(request.form.get('due_date'), '%Y-%m-%d').date()
            assigned_to = request.form.get('assigned_to')
            
            if not all([new_hire_id, title, due_date, assigned_to]):
                flash('Please fill in all required fields', 'danger')
                return redirect(url_for('onboarding'))
            
            task = OnboardingTask(
                title=title,
                description=description,
                due_date=due_date,
                assigned_to=assigned_to,
                new_hire_id=new_hire_id,
                created_by=current_user.id
            )
            db.session.add(task)
            db.session.commit()
            flash('Onboarding task created successfully', 'success')
            return redirect(url_for('onboarding'))
        except Exception as e:
            db.session.rollback()
            flash(f'Error creating task: {str(e)}', 'danger')
            return redirect(url_for('onboarding'))
    
    # For GET request
    if current_user.role in ['admin', 'hr', 'manager']:
        # Admin, HR, and managers can see all tasks
        tasks = OnboardingTask.query.order_by(OnboardingTask.created_at.desc()).all()
        # Get all active users that can be new hires
        new_hires = User.query.filter(
            User.role.in_(['employee', 'trainee', 'team_leader']),
            User.id != current_user.id
        ).all()
        # Get all users that can be assigned tasks
        assignees = User.query.filter(
            User.role.in_(['admin', 'hr', 'manager', 'team_leader']),
            User.id != current_user.id
        ).all()
    else:
        # Regular users can only see tasks assigned to them or where they are the new hire
        tasks = OnboardingTask.query.filter(
            (OnboardingTask.assigned_to == current_user.id) |
            (OnboardingTask.new_hire_id == current_user.id)
        ).order_by(OnboardingTask.created_at.desc()).all()
        new_hires = None
        assignees = None
    
    return render_template('onboarding.html', 
                         tasks=tasks, 
                         new_hires=new_hires, 
                         assignees=assignees,
                         current_user_role=current_user.role)

@app.route('/onboarding/task/<int:task_id>/update', methods=['POST'])
@login_required
def update_onboarding_task(task_id):
    task = OnboardingTask.query.get_or_404(task_id)
    if current_user.id not in [task.assigned_to, task.new_hire_id] and current_user.role not in ['admin', 'hr']:
        return jsonify({'success': False, 'message': 'Unauthorized'}), 403
    
    status = request.json.get('status')
    if status not in ['pending', 'in_progress', 'completed']:
        return jsonify({'success': False, 'message': 'Invalid status'}), 400
    
    task.status = status
    if status == 'completed':
        task.completed_at = datetime.utcnow()
    
    db.session.commit()
    return jsonify({'success': True})

# Company Culture Routes
@app.route('/culture', methods=['GET'])
@login_required
def culture():
    events = CompanyEvent.query.filter(
        CompanyEvent.end_date >= datetime.utcnow()
    ).order_by(CompanyEvent.start_date).all()
    
    spotlights = EmployeeSpotlight.query.filter_by(
        is_active=True
    ).order_by(EmployeeSpotlight.created_at.desc()).all()
    
    return render_template('culture.html', events=events, spotlights=spotlights)

@app.route('/culture/event', methods=['POST'])
@login_required
def create_event():
    if current_user.role not in ['admin', 'manager']:
        return jsonify({'success': False, 'message': 'Unauthorized'}), 403
    
    try:
        event = CompanyEvent(
            title=request.form.get('title'),
            description=request.form.get('description'),
            event_type=request.form.get('event_type'),
            start_date=datetime.strptime(request.form.get('start_date'), '%Y-%m-%dT%H:%M'),
            end_date=datetime.strptime(request.form.get('end_date'), '%Y-%m-%dT%H:%M'),
            location=request.form.get('location'),
            organizer_id=current_user.id
        )
        db.session.add(event)
        db.session.commit()
        return jsonify({'success': True})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/culture/spotlight', methods=['POST'])
@login_required
def create_spotlight():
    if current_user.role not in ['admin', 'hr']:
        return jsonify({'success': False, 'message': 'Unauthorized'}), 403
    
    try:
        spotlight = EmployeeSpotlight(
            employee_id=request.form.get('employee_id'),
            title=request.form.get('title'),
            content=request.form.get('content'),
            image_url=request.form.get('image_url')
        )
        db.session.add(spotlight)
        db.session.commit()
        return jsonify({'success': True})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

# Meeting Management Routes
@app.route('/meetings', methods=['GET', 'POST'])
@login_required
def meetings():
    if request.method == 'POST':
        try:
            meeting = Meeting(
                title=request.form.get('title'),
                description=request.form.get('description'),
                start_time=datetime.strptime(request.form.get('start_time'), '%Y-%m-%dT%H:%M'),
                end_time=datetime.strptime(request.form.get('end_time'), '%Y-%m-%dT%H:%M'),
                location=request.form.get('location'),
                organizer_id=current_user.id,
                status='scheduled'  # Add default status
            )
            db.session.add(meeting)
            
            # Add attendees
            attendee_ids = request.form.getlist('attendees')
            for user_id in attendee_ids:
                attendee = MeetingAttendee(meeting_id=meeting.id, user_id=user_id)
                db.session.add(attendee)
            
            # Add agenda items
            agenda_items = request.form.getlist('agenda_items[]')
            for i, item in enumerate(agenda_items):
                agenda = MeetingAgenda(
                    meeting_id=meeting.id,
                    title=item,
                    order=i
                )
                db.session.add(agenda)
            
            db.session.commit()
            return jsonify({'success': True, 'message': 'Meeting created successfully'})
        except Exception as e:
            db.session.rollback()
            return jsonify({'success': False, 'message': str(e)}), 500
    
    # Get meetings based on user role
    if current_user.role in ['admin', 'manager']:
        meetings = Meeting.query.order_by(Meeting.start_time).all()
    else:
        meetings = Meeting.query.join(
            MeetingAttendee,
            Meeting.id == MeetingAttendee.meeting_id
        ).filter(
            MeetingAttendee.user_id == current_user.id
        ).order_by(Meeting.start_time).all()
    
    # Get all users for the attendees dropdown
    users = User.query.all()
    return render_template('meetings.html', meetings=meetings, users=users)

@app.route('/meetings/<int:meeting_id>', methods=['GET'])
@login_required
def meeting_details(meeting_id):
    meeting = Meeting.query.get_or_404(meeting_id)
    if current_user.id not in [a.user_id for a in meeting.attendees] and current_user.role not in ['admin', 'manager']:
        flash('Unauthorized access', 'danger')
        return redirect(url_for('meetings'))
    
    return render_template('meeting_details.html', meeting=meeting)

@app.route('/meetings/<int:meeting_id>/minutes', methods=['POST'])
@login_required
def add_meeting_minutes(meeting_id):
    meeting = Meeting.query.get_or_404(meeting_id)
    if current_user.id not in [a.user_id for a in meeting.attendees]:
        return jsonify({'success': False, 'message': 'Unauthorized'}), 403
    
    try:
        minute = MeetingMinute(
            meeting_id=meeting_id,
            content=request.form.get('content'),
            created_by=current_user.id
        )
        db.session.add(minute)
        db.session.commit()
        return jsonify({'success': True})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/meetings/<int:meeting_id>/action_items', methods=['POST'])
@login_required
def add_action_item(meeting_id):
    meeting = Meeting.query.get_or_404(meeting_id)
    if current_user.id not in [a.user_id for a in meeting.attendees]:
        return jsonify({'success': False, 'message': 'Unauthorized'}), 403
    
    try:
        action_item = ActionItem(
            meeting_id=meeting_id,
            title=request.form.get('title'),
            description=request.form.get('description'),
            assigned_to=request.form.get('assigned_to'),
            due_date=datetime.strptime(request.form.get('due_date'), '%Y-%m-%d').date()
        )
        db.session.add(action_item)
        db.session.commit()
        return jsonify({'success': True})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/admin/dashboard')
@login_required
@admin_or_manager_required
def admin_dashboard():
    # Get all users based on role
    if current_user.role == 'admin':
        all_users = User.query.filter(User.role != 'admin').all()
    else:  # manager
        all_users = User.query.filter(
            User.role.in_(['team_leader', 'employee', 'trainee'])
        ).all()
    
    # Count users by role
    team_leaders = [u for u in all_users if u.role == 'team_leader']
    employees = [u for u in all_users if u.role == 'employee']
    trainees = [u for u in all_users if u.role == 'trainee']
    
    return render_template('admin_dashboard.html',
                         team_leaders_count=len(team_leaders),
                         managers_count=0,  # Managers can't see other managers
                         employees_count=len(employees),
                         trainees_count=len(trainees),
                         users=all_users,
                         is_admin=False)

if __name__ == '__main__':
    init_db()  # Initialize database with new schema
    app.run(debug=True)